import React from 'react'
import { connect } from 'react-redux'

class Home extends React.Component {
    render() {
        return (
            <div>
                <h1>อายุของคุณ: {this.props.age} ปี</h1>
                <button onClick={this.props.upAge} className="btn btn-primary">+ อายุ</button>{' '}
                <button onClick={this.props.downAge} className="btn btn-danger">- อายุ</button>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        age: state.counter
    }
}

function mapDispatchToProps(dispatch) {
    return {
        downAge: () => {
            dispatch({type: 'DOWNAGE'})
        },
        upAge: () => {
            dispatch({ type: 'UPAGE' })
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home)